/**
 * 
 */
/**
 * 
 */
module projectv3 {
	requires java.desktop;
}